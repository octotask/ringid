<pre>Array
(
    [currentFolderPath] => ../uploaded/3/New Folder/
    [new_folder] => sdfds
)
</pre>

28/Aug/2008 22:57:37