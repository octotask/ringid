<?php die(); ?>
gc start at 02/Sep/2011 05:50:17
