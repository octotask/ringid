tinyMCE.addI18n('en.codeprotect',{
desc : 'CodeProtect'
});
