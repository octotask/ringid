tinyMCE.addI18n('en.codeprotect_dlg',{
title : 'CodeProtect'
});
