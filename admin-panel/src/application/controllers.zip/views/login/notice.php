<div class="bdr">
    <div class='login_bg'>
        <div class="ui-jqdialog-titlebar ui-widget-header ui-corner-all ui-helper-clearfix" style="padding:10px;"><span class="ui-jqdialog-title" style="float: left;">Notice</span></div>
        <div class='login_box'>
            <div class="table txt_center">
                    <?php if($msg!='') {
    echo "<div class='b'>".$msg."</div>";
}?>
            </div>
        </div>
    </div>
</div>