<div id="footer">
    Copyright &copy; <?=date('Y')?> All right Reserved Flamma Corporation Ltd.
</div>
<?php common::track_uri();?>